# Arduino-Snake-Game-with-2.2-TFT-Screen
Arduino Snake Game with 2.2" TFT Screen and Joystick

Die Bibliotheken SPI.h, Adafruit_GFX.h, Adafruit_ILI9341.h müssen innerhalb der Entwicklungsumgebung installiert werden.
The libraries must SPI.h, Adafruit_GFX.h, Adafruit_ILI9341.h must be installed within the development environment.
