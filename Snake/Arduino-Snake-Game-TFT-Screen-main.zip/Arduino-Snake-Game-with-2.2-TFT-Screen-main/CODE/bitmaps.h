#ifndef BITMAPS_H
#define BITMAPS_H

extern const unsigned char wellcome_snake[];
extern const unsigned char dead_snake[];

#endif
